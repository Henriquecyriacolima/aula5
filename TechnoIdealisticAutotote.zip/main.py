# print()
# cidade =  ' guarulhos'
# print (cidade,"\n")
# frang = list(cidade )
# # print(frang)

# tr =  tuple(frag)
# print (tr)



# numero = range(1,11,1)
# print(numero)


# n = range(1,3)
# print(n)


# lista =  {10,6,56} 
# soma =sum(lista)
# print( "a soma de tudo é:",soma)




# min(), max(): Encontra o valor mínimo e máximo em uma sequência.


# listao= ['a','s','d','r','y']
# list = [56,65,68,67,78,14]
# organize = sorted(list+listao)
# print 




# for i  in  range (0,51): 
#   print (i)

# for n  in range(1,13):
#   print (n)







# Aula 3

# len = comprimento (quantidade)

# nome_da_cidade = 'Guarulhos'
# comprimento = len(nome_da_cidade)
# print(comprimento)

# dia_da_semana = 'sabado'
# print(len(dia_da_semana))

# x = 4
# print(type(x))

# x = 'terra'
# dado = x
# print(type(dado))

# z = '45'
# n = float(z)
# print(int(z))
# print(n+5)

# cidade = 'Guarulhos'
# print(cidade, '\n')
# frag = list(cidade)
# print(frag)

# tr = tuple(frag)
# print(tr)

# numero = range(1,11,2)
# print(numero)

# n = range (1,3)
# print(n)

# lista = [1,6,812,0,45]
# soma = sum(lista)
# print('a soma de tudo é', soma)

# lista = [100,36,145,1]
# maxi = max(lista)
# print(maxi)

# lista = [100,36,145,1]
# mini = min(lista)
# print(mini)

# lista = [56,566,7878,15,1,0,89,10]
# organize = sorted(lista)
# print(organize)

# lista = ['a','e','r','g','b','y','t','j']
# organize = sorted(lista)
# print(organize)

# for i in range(1,51):
#     print(i)

# for n in range(1,13,2):
#   print(n)





# :exercio pagina 5 


# for i in range(5,55,5):
# print(i)
# list = range(5,50,5)
# soma = sum(list)
# print ("a soma de tudo e", soma)

    































# Exercício 3: Escreva um programa que use a função type() para verificar o tipo de uma variável.





# x = 4
# print(type(x))




  
# Exercício 4: Escreva um programa que use a função print() para imprimir uma mensagem de saudação personalizada, incluindo o nome do usuário.


# nome = input("quem fala  ")
# print ("ola", nome)


# **Exercício 5:** Escreva um programa que use a função `range()` para gerar os números ímpares de 1 a 10 e, em seguida, calcule e imprima a média desses números.





# dicionario 



dados = {'nome': 'julio' , 'idade': 18,  'endereco':'rua 10'}

for i1,i2 in dados.items():
  print (f'{i1} : {i2}')




  
  


























# palavra =  'python'
# for  letra in palavra:
#   print(letra)
  



# numeros = range(1, 10) 










# lista = [ 'maçã', 'banana', 'cereja' ,'uva'3]


# for i in lista:
#  print(i[2])






































